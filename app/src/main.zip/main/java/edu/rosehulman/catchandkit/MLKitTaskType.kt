package edu.rosehulman.catchandkit

enum class MLKitTaskType {
    OCR, OCR_CLOUD, LABEL
}
